function start(){
	document.turn = "X";
	document.winner = null;
	display_msg(document.turn + " starts the game");
	}

function next(button){
if (document.winner != null){
	display_msg("Please refresh page for new game!");
}
else if(button.innerText == ''){
button.innerText = document.turn;
X_to_O();
}
else {
	display_msg("Please refresh page for new game!");
}
}

function display_msg(msg){
	document.getElementById("message").innerText = msg;
}

function X_to_O(){
    if(show_winner(document.turn)) {
	display_msg(document.turn + " IS THE WINNER!");
	document.winner = document.turn;
	}
	else if(document.turn == "X"){
		document.turn = "O";
		display_msg(document.turn + " make your move");
		}
	else{
		document.turn = "X";
		display_msg(document.turn + " make your move");
		}
}

function show_winner(move){
var result = false;
if(check_row(1,2,3,move) || check_row(1,4,7,move) || check_row(1,5,9,move) || check_row(4,5,6,move) || check_row(7,8,9,move) || check_row(3,5,7,move) || check_row(3,6,9,move) || check_row(2,5,8,move)){
	result = true;
}
return result;
}

function check_row(x,y,z,move){
var result = false;
if(get_but(x) == move && get_but(y) == move && get_but(z) == move) {
	result = true;
}
return result;
}

function get_but(num){
	return document.getElementById(num).innerText;
}

/*
function restart(){
var i = 0;
for(i = 1;i <= 9; i++){
var no = document.getElementById(i.toString());
no.innerText = "";
}
}
*/

